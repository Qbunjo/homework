package funkcje_tablicowe;

public class Sumowanie2 {

	static int suma(int[] t) {
		int result = 0;
		for (int value : t) {
			result += value;
		}
		return result;
	}
	
	static int Sumapary(int[] t) {
		int result = 0;
		for (int value : t) {
			if (value % 2 == 0) {
				result+=value;}
		}
		return result;
	}

	static int Liczbapary(int[] t) {
		int parzyste = 0;
		for (int value : t) {
			if (value % 2 == 0) {
				parzyste++;}
		}
		return parzyste;
	}

	public static void main(String[] args) {
		int[] a = { 5, 10, 15 };
		int[] b = { 2, 3, 5, 10, 3, 8, 1, 11 };
		System.out.println("suma z a: " + suma(a));
		System.out.println("suma z b: " + suma(b));
		System.out.println("suma parzystych w a: "+Sumapary(a));
		System.out.println("suma parzystych w b: "+Sumapary(b));
		System.out.println("liczba parzystych w a: "+ Liczbapary(a));
		System.out.println("liczba parzystych w b: "+ Liczbapary(b));
		
	}

}
