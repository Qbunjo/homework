package funkcje_tablicowe;

public class Sumowanie {
	
	static int suma (int []t) {
		int result=0;
		for (int p:t) {
			result +=p;
		}
		return result;
	}

	public static void main(String[] args) {
		int []a= {5,10,15};
		int []b = {2,3,5,10,3,8,1,11};
		System.out.println("suma a: "+suma (a));
		System.out.println("suma b: "+suma (b));
	}

}
