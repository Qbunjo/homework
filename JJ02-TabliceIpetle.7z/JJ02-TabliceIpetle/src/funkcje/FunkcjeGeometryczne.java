package funkcje;

public class FunkcjeGeometryczne {
	
	//domyslna widoczność to widoczność na poziomie pakietu
	// mozna ją zmniejszać ((private) lub zwiększać (public) - wtedy wszystkie klasy z pakietów mają dostęp
	static double poleKwadratu(double a) {
		return a*a;
	}
	static double poleProstokata(double a, double b) {
		return a*b;
	}
	static double poleKola (double r) {
		return (Math.PI*r*r);
		//return Math.PI*Math.pow(r,2);
	}
	
}
