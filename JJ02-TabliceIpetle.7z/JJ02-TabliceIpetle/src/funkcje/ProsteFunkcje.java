package funkcje;

import java.util.Scanner;

public class ProsteFunkcje {
	static int wiekszy(int x, int y) {
		if (x > y) {
			return x;
		}
		if (x < y) {
			return y;
		} else
			return y;
	}

	static int wiekszy2(int x, int y) {
		return Math.max(x, y);
	}

	static int wiekszy3(int x, int y) {
		// wyrażenie warunkowe
		return x > y ? x : y;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Podaj dwie liczby: ");
		int a = sc.nextInt();
		int b = sc.nextInt();
		int wynik = wiekszy(a, b);
		System.out.println("Większa jest " + wynik);

	}

}
