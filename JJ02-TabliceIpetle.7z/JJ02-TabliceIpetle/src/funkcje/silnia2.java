package funkcje;

import java.util.Scanner;

public class silnia2 {

	static long silnia(int n) {
		long result = 1;
		for (int i = 1; i <= n; i++) {

			result *= i;
		}
		return result;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Podaj argument:");
		int n = sc.nextInt();

		long wynik = silnia(n);
		System.out.println("Wynik: " + wynik);
		sc.close();
	}

}
