package funkcje;

import static funkcje.FunkcjeGeometryczne.poleKola;
import static funkcje.FunkcjeGeometryczne.poleKwadratu;
import static funkcje.FunkcjeGeometryczne.poleProstokata;
// mozna tez z gwiazdką: import static funkcje.FunkcjeGeometryczne.*;

import java.util.Scanner;

public class ProgramGeometryczny2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Co chcesz obliczyć?");
        System.out.println(" 1 - pole kwadratu");
        System.out.println(" 2 - pole prostokąta");
        System.out.println(" 3 - pole koła");
        System.out.print("> ");
        int wybor = sc.nextInt();
        switch(wybor) {
            case 1: {
                System.out.println("Podaj długość boku: ");
                double bok = sc.nextDouble();
                double wynik = poleKwadratu(bok);
                System.out.println("Pole kwadratu wynosi " + wynik);
                break;
            }

            case 2: {
                System.out.println("Podaj długość boków: ");
                double bok1 = sc.nextDouble();
                double bok2 = sc.nextDouble();
                double wynik = poleProstokata(bok1, bok2);
                System.out.println("Pole prostokąta wynosi " + wynik);
                break;
            }

            case 3: {
                System.out.println("Podaj promień koła: ");
                double promien = sc.nextDouble();
                double wynik = poleKola(promien);
                System.out.println("Pole koła wynosi: "+wynik);
                break;
            }

            
        }
    }
}
