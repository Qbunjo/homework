
package funkcje;

import java.util.Scanner;

public class silniaRekurencja {

	static int silnia(int n) {
		if (n <= 1) {
			return 1;
		} else {
			return n * silnia(n - 1);
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Podaj argument:");
		int n = sc.nextInt();

		int wynik = silnia(n);
		System.out.println("Wynik: " + wynik);
		sc.close();
	}

}
