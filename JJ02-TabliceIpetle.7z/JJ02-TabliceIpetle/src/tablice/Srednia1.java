package tablice;

public class Srednia1 {
		public static void main(String[] args) {
		double[] liczby = { 32.1, 15.4, 23.4, 17.4, 19.1, 20.4, 54.5 };
		double wynik = 0;
		for (int i = 0; i < liczby.length; i++) {
			wynik += liczby[i];
		}
		wynik = wynik / liczby.length;
		System.out.println("srednia liczb z tablicy:"+wynik);
		//Wersja 2:
		
	}
		
}
