package tablice;

import java.util.Arrays;

public class Tablice {

	public static void main(String[] args) {
		String[] miasta = {"Gdańsk", "Sopot", "Gdynia"};
		int [] liczby = new int[10];
		System.out.println("Miasta:" +Arrays.toString(miasta));
		System.out.println("Liczby:"+ Arrays.toString(liczby));
		System.out.println();
		System.out.println("rozmiar tablicy miasta: "+miasta.length);
		System.out.println("rozmiar tablicy liczby: "+liczby.length);
		
		//odwołąnie do elementu tablicy tablica[indeks]
		//może być używane jak zwykła zmienna zarówno do oczytu, jak i zmiany wartości
		System.out.println(miasta[1]);
		liczby[0]=100;
		liczby[1]=101;
		liczby[5]=105;
		System.out.println("Liczby:"+ Arrays.toString(liczby));
		System.out.println();
		liczby[1]+=50;
		// w Javie nie ma jak zwolnić pamięci po tablicach
		//usuwaniem tablic zajmuje się tzw. garbage collector, który zarządza pamięcią
	}

	}

