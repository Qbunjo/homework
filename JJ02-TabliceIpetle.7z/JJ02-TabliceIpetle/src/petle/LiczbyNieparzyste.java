package petle;

import java.util.Scanner;

public class LiczbyNieparzyste {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("podaj limit");
		int limit = sc.nextInt();
		int i;
		for (i = 1; i <= limit; i++) {
			if (i % 2 != 0) {
				System.out.println("Liczba:" + i);
			}
		}
		
		int x=1;
		while (x<=limit) {
			System.out.println(x);
			x+=2;
		}
		
		sc.close();
	}
}