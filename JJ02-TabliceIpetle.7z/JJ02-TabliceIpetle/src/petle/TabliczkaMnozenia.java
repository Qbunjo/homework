package petle;

public class TabliczkaMnozenia {

	public static void main(String[] args) {
		for (int x = 1; x <= 10; x++) { //first loop
			for (int y = 1; y <= 10; y++) { //second loop
				System.out.printf("%3d ", (x * y)); //pattern to print result 
			}
			System.out.println(); // next line
		}

	}
}